<template>
  <div>
    <h1>👤 Meu Perfil</h1>
    <p>Informações da conta:</p>
    <!-- Simulação -->
    <ul>
      <li>Nome: Erik</li>
      <li>Saldo: R$ 250,00</li>
      <li>Email: erik@email.com</li>
    </ul>
  </div>
</template>
