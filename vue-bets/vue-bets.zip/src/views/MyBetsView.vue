<template>
  <div>
    <h1>🧾 Minhas Apostas</h1>
    <p>Acompanhe o status das suas apostas:</p>
    <!-- Simulação -->
    <ul>
      <li>Corinthians x São Paulo - Apostou: Empate - Status: Em andamento</li>
      <li>Flamengo x Palmeiras - Apostou: V1 - Status: Ganhou 🎉</li>
    </ul>
  </div>
</template>
