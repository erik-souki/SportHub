<template>
  <div class="min-h-screen bg-gray-100 flex items-center justify-center">
    <div class="bg-white rounded-xl p-6 shadow-xl text-center">
      <h1 class="text-2xl font-bold text-blue-600 mb-4">
        Tailwind está funcionando! ✅
      </h1>
      <p class="text-gray-700">Agora você pode começar a construir sua plataforma de apostas!</p>
    </div>
  </div>
</template>
